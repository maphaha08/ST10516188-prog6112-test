/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package gamingconsole;

/**
 *
 * @author Student
 */
public class GamingConsole {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
       
        //Single-dimensional arrays for each city.
        String[] cities = {"Cape Town", "Port Elizabeth", "Pretoria"};
        
        //single-dimensional arrays for each console
        String[] consoles = {"PSS", "XBOX", "SWITCH"};
        
        //Two-dimensional arrays for each sales
        int[][] sales = {
            {1000, 2000, 3000},
            {2000, 3000, 4000},
            {1500, 1100, 1200}};
            
        //Arrays to store the total of sales for each city
        int[] cityTotals = new int[cities.length];
        
       //Calculate total sales to each city
       for (int i = 0; i < sales.length; i++){
           for (int j = 0; j < sales[i].length; j++) {
               cityTotals[i] = cityTotals[i] + sales[i][j];
           }
       }
       
        //Display the report
        System.out.println("------------------------------------------------------------");
        System.out.println("                 GAMING CONSOLES REPORT");
        System.out.println("------------------------------------------------------------");

        System.out.printf("%-20s %-10s %-10s %-10s%n",

                "CITY", "PS5", "XBOX", "SWITCH");

        for (int i = 0; i < cities.length; i++) {

            System.out.printf("%-20s %-10d %-10d %-10d%n",

                    cities[i],

                    sales[i][0],

                    sales[i][1],

                    sales[i][2]);

        }

        System.out.println();

        System.out.println("------------------------------------------------------------");

        System.out.println("          CONSOLE SALES TOTALS FOR EACH CITY");

        System.out.println("------------------------------------------------------------");

        for (int i = 0; i < cities.length; i++) {

            System.out.printf("%-20s %d%n", cities[i], cityTotals[i]);

        }

        // Find the city with the highest sales

        int highestSales = cityTotals[0];

        String cityWithMostSales = cities[0];

        for (int i = 1; i < cityTotals.length; i++) {

            if (cityTotals[i] > highestSales) {

                highestSales = cityTotals[i];

                cityWithMostSales = cities[i];

            }

        }

        System.out.println();
        System.out.println("CITY WITH THE MOST SALES: " + cityWithMostSales);
        System.out.println("------------------------------------------------");
    }
}
     
       
     
    
    
    

