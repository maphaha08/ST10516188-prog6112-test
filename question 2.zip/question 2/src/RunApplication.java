/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author Student
 */
public class RunApplication {
    public  static void main(String[] args) {
    
    ConsoleSales sales = new ConsoleSales("PS5", "Number 1 Eloctronics", 1500);
    
    sales.printReport();
}
}
